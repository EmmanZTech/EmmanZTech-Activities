const { Server } = require("socket.io");

function setupChat(server) {
  const allowedOrigins = (process.env.SOCKET_CORS_ORIGIN || "")
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean);
  const io = new Server(server, { cors: { origin: allowedOrigins } });

  io.on("connection", (socket) => {
    socket.on("message", (text, acknowledge) => {
      if (typeof text !== "string" || !text.trim() || text.trim().length > 3000) {
        const error = "Message must not be empty or longer than 3000 characters";
        if (typeof acknowledge === "function") {
          acknowledge({ success: false, error });
        } else {
          socket.emit("message:error", { error });
        }
        return;
      }

      io.emit("message", {
        text: text.trim(),
        senderId: socket.id,
        sentAt: new Date().toISOString()
      });

      if (typeof acknowledge === "function") {
        acknowledge({ success: true });
      }
    });
  });
}

module.exports = setupChat;
